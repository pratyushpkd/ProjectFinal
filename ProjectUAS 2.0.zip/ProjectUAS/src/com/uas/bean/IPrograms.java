package com.uas.bean;

import java.util.ArrayList;
import java.util.List;

public interface IPrograms {
	List<ProgramsOfferedBean> programsOffered = new ArrayList<ProgramsOfferedBean>();
	List<ProgramsScheduledBean> programsScheduled = new ArrayList<ProgramsScheduledBean>();
}
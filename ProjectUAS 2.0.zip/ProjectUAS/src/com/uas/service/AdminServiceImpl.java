package com.uas.service;

import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.dao.AdminDAOImpl;
import com.uas.dao.IAdminDAO;
import com.uas.exception.UserException;

public class AdminServiceImpl implements IAdminService {

	private IAdminDAO adminDAO;

	public AdminServiceImpl() {
		adminDAO = new AdminDAOImpl();
	}

	@Override
	public boolean isAuthenticated(UserBean userBean)
			throws UserException {

		return adminDAO.isAuthenticated(userBean);
	}

	@Override
	public boolean deleteProgramOffered(String programName)
			throws UserException {
		return adminDAO.deleteProgramOffered(programName);
	}

	@Override
	public boolean addProgramOffered(ProgramsOfferedBean programsOfferedBean)
			throws UserException {

		return adminDAO.addProgramOffered(programsOfferedBean);
	}

	@Override
	public List<ProgramsScheduledBean> viewProgramsScheduled()
			throws UserException {

		return adminDAO.viewProgramsScheduled();
	}

	@Override
	public boolean deleteProgramScheduled(String programId)
			throws UserException {

		return adminDAO.deleteProgramScheduled(programId);
	}

	@Override
	public boolean addProgramScheduled(
			ProgramsScheduledBean programsScheduledBean) throws UserException {

		return adminDAO.addProgramScheduled(programsScheduledBean);
	}

	@Override
	public List<ApplicantBean> viewListOfApplicants() throws UserException {

		return adminDAO.viewListOfApplicants();
		/*
		 * List<ApplicantBean> applicantList=adminDAO.viewListOfApplicants();
		 * return applicantList;
		 */

	}

}

package com.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.exception.UserException;
import com.uas.util.DBConnection;

/**
 *  Author : KAMAL, GUNJAN
 *  Class Name : ApplicantDAOImpl 
 *  Package :com.uas.dao 
 *  Date : December 09, 2017
 */
public class ApplicantDAOImpl implements IApplicantDAO {

	
	/**************************************************************
	 * - Method Name : viewPrograms() 
	 * - Input Parameters :  
	 * - Return Type :List<ProgramsScheduledBean> 
	 * - Throws : CustomException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of programs offered along with programs scheduled
	 *************************************************************/
	@Override
	public List<ProgramsScheduledBean> viewPrograms() throws UserException {
		List<ProgramsScheduledBean> programList = new ArrayList<ProgramsScheduledBean>();
		try(Connection connPrograms = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
						connPrograms.prepareStatement(ApplicantQueryMapper.VIEW_PROGRAMS);
				ResultSet rsPrograms = preparedStatement.executeQuery();
				){
			
			while(rsPrograms.next()){
				ProgramsOfferedBean offeredBean = new ProgramsOfferedBean();
				ProgramsScheduledBean scheduledBean = new ProgramsScheduledBean();
				offeredBean.setProgramName(rsPrograms.getString("ProgramName"));
				offeredBean.setDescription(rsPrograms.getString("description"));
				offeredBean.setApplicantEligibility(rsPrograms.getString("applicant_eligibility"));
				offeredBean.setDuration((byte)rsPrograms.getInt("duration"));
				offeredBean.setDegreeOffered(rsPrograms.getString("degree_certificate_offered"));
				scheduledBean.setProgramsOfferedBean(offeredBean);
				scheduledBean.setProgramId(rsPrograms.getString("Scheduled_program_id"));
				scheduledBean.setCity(rsPrograms.getString("City"));
				scheduledBean.setState(rsPrograms.getString("State"));
				scheduledBean.setZipCode(rsPrograms.getInt("Zipcode"));
				scheduledBean.setStartDate(rsPrograms.getDate("start_date").toLocalDate());
				scheduledBean.setEndDate(rsPrograms.getDate("end_date").toLocalDate());
				scheduledBean.setSessionPerWeek((byte)rsPrograms.getInt("sessions_per_week"));
				programList.add(scheduledBean);
				/*IPrograms.programsOffered.add(offeredBean);
				IPrograms.programsScheduled.add(scheduledBean);*/
			}
			
		}catch(SQLException sqlEx){
			throw new UserException("No data found");
		}	
		
		return programList;
	}

	
	/**************************************************************
	 * - Method Name : insertApplicant(ApplicantBean applicantBean,String programName) 
	 * - Input Parameters :  ApplicantBean, String
	 * - Return Type :int 
	 * - Throws : CustomException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : insert new applicant details
	 *************************************************************/
	@Override
	public int insertApplicant(ApplicantBean applicantBean,String programName) throws UserException {
		try(Connection connInsert = DBConnection.getInstance().getConnection();	){
			PreparedStatement preparedStatement = connInsert.prepareStatement(ApplicantQueryMapper.GET_PROGRAM_SCHEDULED_ID);
			preparedStatement.setString(1, programName);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next()){
				String programId = resultSet.getString(1);
				java.sql.Date translateDate = java.sql.Date.valueOf(applicantBean.getDateOfBirth());
				
				preparedStatement =	connInsert.prepareStatement(ApplicantQueryMapper.INSERT_APPLICANT);
				preparedStatement.setString(1, applicantBean.getFullName());
				preparedStatement.setDate(2, translateDate);
				preparedStatement.setString(3, applicantBean.getHighestQualification());
				preparedStatement.setInt(4, applicantBean.getMarksObtained());
				preparedStatement.setString(5, applicantBean.getGoals());
				preparedStatement.setString(6, applicantBean.getEmailId());
				preparedStatement.setString(7, programId);
				
				int records  = preparedStatement.executeUpdate();
				if(records>0){
					preparedStatement =	connInsert.prepareStatement(ApplicantQueryMapper.GET_APPLICATION_ID);
					resultSet = preparedStatement.executeQuery();
					resultSet.next();
					return resultSet.getInt(1);
				}
			}
		}catch(SQLException sqlEx){
			throw new UserException("Invalid data");
		}
		return 0;
	}

	
	/**************************************************************
	 * - Method Name : viewStatus() 
	 * - Input Parameters :  int
	 * - Return Type :Application_Status 
	 * - Throws : CustomException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of status of an applicant according to applicantId
	 *************************************************************/
	@Override
	public Application_Status viewStatus(int applicantId) throws UserException {
		
		Application_Status status = null;
		
		try(Connection connStatus = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
						connStatus.prepareStatement(ApplicantQueryMapper.VIEW_STATUS);
				){
			preparedStatement.setInt(1, applicantId);
			
			ResultSet rsStatus = preparedStatement.executeQuery();
			
			if(rsStatus.next()){
				status = Application_Status.valueOf(rsStatus.getString("status")); 
			}
		}catch(SQLException sqlEx){
			throw new UserException("No applicant found with id"+applicantId);
		}
		return status;
	}


	@Override
	public String[] getApplicantInfo(int applicationId) throws UserException {
		try(Connection connStatus = DBConnection.getInstance().getConnection();	
			PreparedStatement preparedStatement=
						connStatus.prepareStatement(ApplicantQueryMapper.GET_EMAIL_ID);
			){	
				String[] info = new String[2];
				preparedStatement.setInt(1, applicationId);
				ResultSet rsApplicant = preparedStatement.executeQuery();
			
			if(rsApplicant.next()){
				info[0] = rsApplicant.getString("email_id");
				info[1] = Integer.toString(rsApplicant.getInt("Scheduled_program_id"));
				return info;
			}
			
		}catch(SQLException sqlEx){
			throw new UserException("No applicant found with id"+applicationId);
		}
		return null;
	}

}
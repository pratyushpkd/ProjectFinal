package com.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.bean.UserRole;
import com.uas.exception.UserException;
import com.uas.util.DBConnection;

public class MacDaoImpl implements IMacDAO {

	@Override
	public boolean isAuthenticated(UserBean userBean) throws UserException {

		boolean isAuthenticated = false;
		try {

			Connection connAdmin = null;

			connAdmin = DBConnection.getInstance().getConnection();

			PreparedStatement pstmt = connAdmin
					.prepareStatement(AdminQueryMapper.IS_AUTHENTICATED);
			pstmt.setString(1, userBean.getLoginId());
			pstmt.setString(2, userBean.getPassword());
			java.sql.ResultSet rst = pstmt.executeQuery();

			while (rst.next()) {
				String login1 = rst.getString("login_id");
				String pass1 = rst.getString("password");
				UserRole roleEnum = UserRole.valueOf(rst.getString("role"));

				if (userBean.getRole().equals(roleEnum)) {

					if (userBean.getLoginId().equals(login1)) {
						if (userBean.getPassword().equals(pass1)) {
							isAuthenticated = true;
						}
					}

				}

			}

		}catch (SQLException se) {
			throw new UserException("Authentication failed");
		}

		return isAuthenticated;

	}

	@Override
	public List<ApplicantBean> viewListOfApplicants(String Scheduled_program_id)
			throws UserException{

		List<ApplicantBean> applicantList = new ArrayList<ApplicantBean>();
		try (Connection conn = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = conn
						.prepareStatement(MacQueryMapper.VIEW_APPLICANTS);
				) {
			preparedStatement.setString(1, Scheduled_program_id);
			ResultSet rsApplicants = preparedStatement.executeQuery();
			while (rsApplicants.next()) {
				ApplicantBean applicantBean = new ApplicantBean();
				ProgramsScheduledBean programsScheduledBean = new ProgramsScheduledBean();

				applicantBean.setApplicationId(rsApplicants.getInt("APPLICATION_ID"));
				applicantBean.setFullName(rsApplicants.getString("FULL_NAME"));
				applicantBean.setDateOfBirth(rsApplicants.getDate("DATE_OF_BIRTH")
						.toLocalDate());
				applicantBean.setHighestQualification(rsApplicants
						.getString("HIGHEST_QUALIFICATION"));
				applicantBean.setMarksObtained(rsApplicants.getInt("MARKS_OBTAINED"));
				applicantBean.setGoals(rsApplicants.getString("GOALS"));
				applicantBean.setEmailId(rsApplicants.getString("EMAIL_ID"));
				programsScheduledBean.setProgramId(rsApplicants
						.getString("SCHEDULED_PROGRAM_ID"));
				applicantBean.setProgramsScheduledBean(programsScheduledBean);
				applicantBean.setStatus(Application_Status.valueOf(rsApplicants
						.getString("STATUS")));
				if (rsApplicants.getDate("DATE_OF_INTERVIEW") == null) {
					applicantBean.setDateOfInterview(null);
				} else {
					applicantBean.setDateOfInterview(rsApplicants.getDate(
							"DATE_OF_INTERVIEW").toLocalDate());
				}

				applicantList.add(applicantBean);
			}

			if (applicantList.size() == 0) {
				throw new UserException("No records found.");
			}

		} catch (SQLException se) {
			throw new UserException("No records found.");
		}

		return applicantList;
	}

	@Override
	public boolean scheduleInterviewDate(int applicationId,Application_Status status, LocalDate dateOfInterview)
			throws UserException {
		boolean isUpdated = false;
		java.sql.Date sqlDate = java.sql.Date.valueOf(dateOfInterview);
		try (Connection conn = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = conn
						.prepareStatement(MacQueryMapper.SCHEDULE_INTERVIEW);) {
			preparedStatement.setString(1, status.name());
			preparedStatement.setDate(2, sqlDate);
			preparedStatement.setInt(3, applicationId);
			int record = preparedStatement.executeUpdate();
			if (record>0) {
				isUpdated = true;
			}
		} catch (SQLException se) {
			throw new UserException("Applicant not found");
		}
		return isUpdated;
	}

	@Override
	public boolean enrollApplicant(int applicationId, Application_Status status)
			throws UserException {
		try(Connection conn = DBConnection.getInstance().getConnection();
			PreparedStatement preparedStatement = 
			conn.prepareStatement(MacQueryMapper.UPDATE_STATUS);){
			preparedStatement.setString(1, status.name());
			preparedStatement.setInt(2, applicationId);
			int records = preparedStatement.executeUpdate();
			if(records>0)
				return true;
		} catch (SQLException e) {
			
			throw new UserException("Applicant not found");
		}
		return false;
	}

}

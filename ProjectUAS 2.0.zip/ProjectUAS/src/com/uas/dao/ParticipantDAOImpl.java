package com.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.uas.bean.ParticipantBean;
import com.uas.exception.UserException;
import com.uas.util.DBConnection;

public class ParticipantDAOImpl implements IParticipantDAO {

	@Override
	public boolean addParticipant(ParticipantBean participantBean, int applicationId, int scheduleId) throws UserException {
		try(Connection conn = DBConnection.getInstance().getConnection();) {
			PreparedStatement preparedStatement = conn.prepareStatement(ParticipantQueryMapper.ADD_PARTICIPANT);
			preparedStatement.setString(1, participantBean.getRollNo());
			preparedStatement.setString(2, participantBean.getEmailId());
			preparedStatement.setInt(3, applicationId);
			preparedStatement.setInt(4, scheduleId);
			if(preparedStatement.executeUpdate()>0)
				return true;
		} catch (SQLException e) {
			throw new UserException("Invalid details");
		}
		return false;
	}

}

package com.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.bean.UserRole;
import com.uas.exception.UserException;
import com.uas.util.DBConnection;

public class AdminDAOImpl implements IAdminDAO {

	@Override
	public boolean isAuthenticated(UserBean userBean) throws UserException {

		boolean isAuthenticated = false;
		try {

			Connection connAdmin = null;

			connAdmin = DBConnection.getInstance().getConnection();

			PreparedStatement pstmt = connAdmin
					.prepareStatement(AdminQueryMapper.IS_AUTHENTICATED);
			pstmt.setString(1, userBean.getLoginId());
			pstmt.setString(2, userBean.getPassword());
			java.sql.ResultSet rst = pstmt.executeQuery();

			while (rst.next()) {
				String login1 = rst.getString("login_id");
				String pass1 = rst.getString("password");
				UserRole roleEnum = UserRole.valueOf(rst.getString("role"));

				if (userBean.getRole().equals(roleEnum)) {

					if (userBean.getLoginId().equals(login1)) {
						if (userBean.getPassword().equals(pass1)) {
							isAuthenticated = true;
						}
					}

				}

			}

		}catch (SQLException se) {
			throw new UserException("Authentication failed");
		}
		return isAuthenticated;

	}

	@Override
	public boolean deleteProgramOffered(String programName)
			throws UserException {

		int records = 0;
		boolean isDeleted = false;

		try (Connection connAdmin = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connAdmin
						.prepareStatement(AdminQueryMapper.DELETE_PROGRAM_OFFERED);) {
			preparedStatement.setString(1, programName);

			records = preparedStatement.executeUpdate();

			if (records > 0) {
				isDeleted = true;
			}
		} catch (SQLException sqlEx) {
			throw new UserException("Program doesn't exist");
		}
		return isDeleted;
	}

	@Override
	public boolean addProgramOffered(ProgramsOfferedBean programsOfferedBean)
			throws UserException {
		int records = 0;
		boolean isInserted = false;

		try (Connection connAdmin = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connAdmin
						.prepareStatement(AdminQueryMapper.ADD_PROGRAM_OFFERED);) {

			preparedStatement
					.setString(1, programsOfferedBean.getProgramName());
			preparedStatement
					.setString(2, programsOfferedBean.getDescription());
			preparedStatement.setString(3,
					programsOfferedBean.getApplicantEligibility());
			preparedStatement.setByte(4, programsOfferedBean.getDuration());
			preparedStatement.setString(5,
					programsOfferedBean.getDegreeOffered());

			records = preparedStatement.executeUpdate();
			if (records > 0) {
				isInserted = true;
			}
		} catch (SQLException sqlEx) {
			throw new UserException("Invalid details");
		}

		return isInserted;
	}

	@Override
	public List<ProgramsScheduledBean> viewProgramsScheduled()
			throws UserException {
		List<ProgramsScheduledBean> programScheduledList = new ArrayList<ProgramsScheduledBean>();

		try (Connection connAdmin = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connAdmin
						.prepareStatement(AdminQueryMapper.VIEW_PROGRAM_SCHEDULED);
				ResultSet rsProgramsScheduled = preparedStatement
						.executeQuery();) {
			while (rsProgramsScheduled.next()) {
				ProgramsScheduledBean admin = new ProgramsScheduledBean();
				ProgramsOfferedBean programsOfferedBean = new ProgramsOfferedBean();

				admin.setProgramId(rsProgramsScheduled
						.getString("Scheduled_program_id"));
				programsOfferedBean.setProgramName(rsProgramsScheduled
						.getString("ProgramName"));
				admin.setProgramsOfferedBean(programsOfferedBean);
				admin.setCity(rsProgramsScheduled.getString("City"));
				admin.setState(rsProgramsScheduled.getString("State"));
				admin.setZipCode(rsProgramsScheduled.getInt("Zipcode"));
				admin.setStartDate(rsProgramsScheduled.getDate("start_date")
						.toLocalDate());
				admin.setEndDate(rsProgramsScheduled.getDate("end_date")
						.toLocalDate());
				admin.setSessionPerWeek(rsProgramsScheduled
						.getByte("sessions_per_week"));

				programScheduledList.add(admin);
			}

			if (programScheduledList.size() == 0) {
				throw new UserException("No programs found.");
			}
		} catch (SQLException sqlEx) {
			throw new UserException("No programs found.");
		}
		return programScheduledList;
	}

	@Override
	public boolean deleteProgramScheduled(String programId)
			throws UserException {

		int records = 0;
		boolean isDeleted = false;

		try (Connection connAdmin = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connAdmin
						.prepareStatement(AdminQueryMapper.DELETE_PROGRAM_SCHEDULED);) {
			preparedStatement.setString(1, programId);

			records = preparedStatement.executeUpdate();

			if (records > 0) {
				isDeleted = true;
			}
		} catch (SQLException sqlEx) {
			throw new UserException("No program found of ID:"+ programId);
		}
		return isDeleted;

	}

	@Override
	public boolean addProgramScheduled(
			ProgramsScheduledBean programsScheduledBean) throws UserException {
		int records = 0;
		boolean isInserted = false;

		try (Connection connAdmin = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connAdmin
						.prepareStatement(AdminQueryMapper.ADD_PROGRAM_SCHEDULED);) {

			preparedStatement
					.setString(1, programsScheduledBean.getProgramId());
			preparedStatement.setString(2, programsScheduledBean
					.getProgramsOfferedBean().getProgramName());
			preparedStatement.setString(3, programsScheduledBean.getCity());
			preparedStatement.setString(4, programsScheduledBean.getState());
			preparedStatement.setInt(5, programsScheduledBean.getZipCode());
			preparedStatement.setDate(6,
					Date.valueOf(programsScheduledBean.getStartDate()));
			preparedStatement.setDate(7,
					Date.valueOf(programsScheduledBean.getEndDate()));
			preparedStatement.setByte(8,
					programsScheduledBean.getSessionPerWeek());

			records = preparedStatement.executeUpdate();
			if (records > 0) {
				isInserted = true;
			}
		} catch (SQLException sqlEx) {
			throw new UserException("Invalid details");
		}

		return isInserted;
	}

	@Override
	public List<ApplicantBean> viewListOfApplicants() throws UserException {

		List<ApplicantBean> applicantList = new ArrayList<ApplicantBean>();

		try (Connection connAdmin = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = connAdmin
						.prepareStatement(AdminQueryMapper.VIEW_APPLICANTS);
				ResultSet rsApplicants = preparedStatement.executeQuery();) {
			while (rsApplicants.next()) {
				ApplicantBean admin = new ApplicantBean();
				ProgramsScheduledBean programsScheduledBean = new ProgramsScheduledBean();

				admin.setApplicationId(rsApplicants.getInt("APPLICATION_ID"));
				admin.setFullName(rsApplicants.getString("FULL_NAME"));
				admin.setDateOfBirth(rsApplicants.getDate("DATE_OF_BIRTH")
						.toLocalDate());
				admin.setHighestQualification(rsApplicants
						.getString("HIGHEST_QUALIFICATION"));
				admin.setMarksObtained(rsApplicants.getInt("MARKS_OBTAINED"));
				admin.setGoals(rsApplicants.getString("GOALS"));
				admin.setEmailId(rsApplicants.getString("EMAIL_ID"));
				programsScheduledBean.setProgramId(rsApplicants
						.getString("SCHEDULED_PROGRAM_ID"));
				admin.setProgramsScheduledBean(programsScheduledBean);
				admin.setStatus(Application_Status.valueOf(rsApplicants
						.getString("STATUS")));
				if (rsApplicants.getDate("DATE_OF_INTERVIEW") == null) {
					admin.setDateOfInterview(null);
				} else {
					admin.setDateOfInterview(rsApplicants.getDate(
							"DATE_OF_INTERVIEW").toLocalDate());
				}

				applicantList.add(admin);
			}

			if (applicantList.size() == 0) {
				throw new UserException("No records found.");
			}
		} catch (SQLException sqlEx) {
			throw new UserException("No records found.");
		}
		return applicantList;
	}

}

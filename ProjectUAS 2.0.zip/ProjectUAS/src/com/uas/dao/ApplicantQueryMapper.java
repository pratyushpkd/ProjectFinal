package com.uas.dao;

public interface ApplicantQueryMapper {
	public static final String VIEW_PROGRAMS = "SELECT o.*, s.* FROM Programs_Offered o, Programs_Scheduled s WHERE o.ProgramName = s.ProgramName";
	public static final String INSERT_APPLICANT = "INSERT INTO APPLICATION (Application_id,full_name,date_of_birth,highest_qualification,marks_obtained,goals,email_id,Scheduled_program_id) "
													+ "VALUES(seq_applicant_id.NEXTVAL,?,?,?,?,?,?,?)";
	public static final String GET_APPLICATION_ID = "SELECT seq_applicant_id.CURRVAL FROM dual";
	public static final String VIEW_STATUS = "SELECT status FROM APPLICATION WHERE Application_id = ?";
	public static final String GET_PROGRAM_SCHEDULED_ID = "SELECT Scheduled_Program_Id FROM Programs_Scheduled WHERE ProgramName =?";
	public static final String GET_EMAIL_ID = "SELECT email_id FROM APPLICATION WHERE Application_id = ?";
}